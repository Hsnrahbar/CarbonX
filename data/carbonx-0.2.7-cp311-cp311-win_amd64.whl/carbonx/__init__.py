"""
Top-level CarbonX package exports.
"""

import warnings

# Suppress known deprecation warnings from dependencies until next major version
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning, message=".*Mean of empty slice.*")
warnings.filterwarnings("ignore", category=RuntimeWarning, message=".*invalid value encountered.*")

from .core import GasReactor, MappingWrapper

# Backward-compatible aliases used by your tests/manual
MovingSectionalModel = GasReactor
Mapping_Wrapper = MappingWrapper

__all__ = [
    "GasReactor",
    "MappingWrapper",
    "MovingSectionalModel",
    "Mapping_Wrapper",
]