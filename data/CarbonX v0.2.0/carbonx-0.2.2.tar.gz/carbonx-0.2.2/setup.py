from pathlib import Path

from setuptools import Distribution, Extension, find_packages, setup

ROOT = Path(__file__).parent.resolve()


class BinaryDistribution(Distribution):
    """Force a platform-specific wheel when binary modules exist."""

    def has_ext_modules(self):
        return True


def build_extensions():
    pyx_files = sorted(ROOT.glob("carbonx/**/*.pyx"))
    if not pyx_files:
        return []

    from Cython.Build import cythonize
    import numpy as np

    extensions = []
    for pyx_path in pyx_files:
        relative_pyx_path = pyx_path.relative_to(ROOT)
        module_name = ".".join(relative_pyx_path.with_suffix("").parts)
        extensions.append(
            Extension(
                module_name,
                [relative_pyx_path.as_posix()],
                include_dirs=[np.get_include()],
            )
        )

    return cythonize(
        extensions,
        compiler_directives={"language_level": "3"},
        annotate=False,
    )


setup(
    name="CarbonX",
    version="0.2.2",
    author="Hossein Rahbar",
    author_email="rahbar.hosein@gmail.com",
    description="CarbonX: A Process Design Tool for Gas-Phase Synthesis of Metal Nanoparticles and Carbon Nanotubes",
    long_description=(ROOT / "README.md").read_text(encoding="utf-8"),
    long_description_content_type="text/markdown",
    url="https://github.com/Hsnrahbar/CarbonX_Package",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "": ["*.pyd", "*.so", "*.dll", "*.yaml", "*.yml"],
        "carbonx": ["*.pyd", "*.so", "data/*.yaml", "data/*.yml"],
        "carbonx.core": ["*.pyd", "*.so"],
        "carbonx.modules": ["*.pyd", "*.so"],
        "carbonx.ml": ["*.pyd", "*.so"],
        "carbonx.data": ["*.yaml", "*.yml"],
    },
    install_requires=[
        "numpy>=1.24.0,<2.0.0",
        "scipy>=1.10.0,<1.14.0",
        "matplotlib>=3.5.0",
        "pandas>=1.5.0,<2.1.0",
        "cantera>=2.6.0",
        "pyyaml>=6.0",
    ],
    python_requires=">=3.8,<3.12",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Chemistry",
        "Topic :: Scientific/Engineering :: Physics",
        "License :: Other/Proprietary License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Cython",
        "Operating System :: Microsoft :: Windows",
    ],
    keywords="Carbon Nanotube  Gas-Phase Synthesis  Metallic Nanoparticles  Machine Learning",
    zip_safe=False,
    distclass=BinaryDistribution,
    ext_modules=build_extensions(),
)